package com.example.my99_expanlistview;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ReservationSubCabi extends AppCompatActivity implements View.OnClickListener {
ExpandableListView exp_listv;
ExpandableListAdapterCabi exp_adpt;
int lastClickPos = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_cabi);
        exp_listv = findViewById(R.id.exp_listv);
        exp_listv.setGroupIndicator(null);

        ArrayList<Cabi_MainDTO> cabi_main = new ArrayList<>();
        ArrayList<Cabi_SubDTO>  cabi_sub = new ArrayList<>();
        for (int i=0; i<5; i++){
            cabi_sub.add(new Cabi_SubDTO(""+i ,""+i,""+i ));
        }
        for (int i=0; i<5; i++){
            cabi_main.add(new Cabi_MainDTO(""+i ,""+i,""+i,cabi_sub ));
        }

        exp_listv.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
              Boolean isExpand = (!exp_listv.isGroupExpanded(groupPosition));
              exp_listv.collapseGroup(lastClickPos);
              if (isExpand){
                  exp_listv.expandGroup(groupPosition);
              }
              setListViewHeightBasedOnChildren(exp_listv);
              lastClickPos = groupPosition;
              return true;
            }
        });

        exp_adpt = new ExpandableListAdapterCabi(getApplicationContext(),exp_listv,cabi_main,cabi_sub);
        exp_listv.setAdapter(exp_adpt);
        exp_adpt.setOnClickListener(new OnTextClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ReservationSubCabi.this, "d", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
// pre-condition
            return;
        }
        int totalHeight = 0;
        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.AT_MOST);
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
//listItem.measure(0, 0);
            listItem.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();

        params.height = totalHeight+50;
        listView.setLayoutParams(params);

        listView.requestLayout();
    }

    @Override
    public void onClick(View v) {

    }
}