package com.example.my99_expanlistview;

import android.view.View;

public interface OnGroupClickListener {
    void onClick(View v);
}
