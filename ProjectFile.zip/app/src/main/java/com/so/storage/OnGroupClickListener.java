package com.so.storage;

import android.view.View;

public interface OnGroupClickListener {
    void onClick(View v);
}
