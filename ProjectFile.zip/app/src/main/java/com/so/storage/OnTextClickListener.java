package com.so.storage;

import android.view.View;

public interface OnTextClickListener {
    void onClick(View v);
}
