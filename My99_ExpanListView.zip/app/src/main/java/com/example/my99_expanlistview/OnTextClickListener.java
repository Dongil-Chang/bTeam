package com.example.my99_expanlistview;

import android.view.View;

public interface OnTextClickListener {
    void onClick(View v);
}
