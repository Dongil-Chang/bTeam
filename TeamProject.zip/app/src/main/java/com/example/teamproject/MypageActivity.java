package com.example.teamproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MypageActivity extends AppCompatActivity {
    TabLayout mypageTab;
    StorageFrag storageFrag;
    ReservationFrag reservationFrag;
    AccountFrag accountFrag;
    AccountSubFrag accountSubFrag;
    MemberLeaveFrag memberLeaveFrag;
    Fragment selected = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);

        storageFrag = new StorageFrag();
        reservationFrag = new ReservationFrag();
        accountFrag = new AccountFrag();
        accountSubFrag = new AccountSubFrag();
        memberLeaveFrag = new MemberLeaveFrag();

        getSupportFragmentManager().beginTransaction().replace(R.id.container, storageFrag).commit();

        mypageTab = findViewById(R.id.mypageTab);
        mypageTab.addTab(mypageTab.newTab().setText("내창고"));
        mypageTab.addTab(mypageTab.newTab().setText("이용내역"));
        mypageTab.addTab(mypageTab.newTab().setText("정보수정"));
        mypageTab.addTab(mypageTab.newTab().setText("회원탈퇴"));

        mypageTab.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int temp_pos = tab.getPosition();
                if(temp_pos == 0) {
                    selected = storageFrag;
                } else if(temp_pos == 1) {
                    selected = reservationFrag;
                } else if(temp_pos == 2) {
                    selected = accountSubFrag;
                } else if(temp_pos == 3) {
                    selected = memberLeaveFrag;
                }
                getSupportFragmentManager().beginTransaction().replace(R.id.container, selected).commit();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    public void FragChange() {
        getSupportFragmentManager().beginTransaction().replace(R.id.container, accountFrag).commit();
    }
}