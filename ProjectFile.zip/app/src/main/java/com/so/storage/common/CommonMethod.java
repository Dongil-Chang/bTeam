package com.so.storage.common;

public class CommonMethod {
    //Spring Server ip 그리고 접속 정보나 상태들을 체크하고
    //Integer값 parsing 등 공통적으로 사용하는 메소드들을 정의하고 사용함
    public static String ipconfig = "http://221.144.89.105:8003";
    public static String project_path = "/storage";

    //네트워크에 연결되어 있는지 체크하는 메소드 추가할 것
}
